<?php

namespace Acme\ShopBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AcmeShopBundle extends Bundle
{
}
